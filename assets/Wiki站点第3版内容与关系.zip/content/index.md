---
title: "陆拾肆企划"
description: "法术与科技并存的架空世界。循着城市、人物与异常档案，阅读陆拾肆企划的世界设定与故事。"
cssclasses:
  - archive-home
---

<div class="archive-hero">
<p class="archive-kicker">世界观知识库 / WORLD ARCHIVE</p>
<h1>陆拾肆企划</h1>
<p class="archive-deck">法术走入城市，<br>未知仍在边界之外。</p>
<p class="archive-lead">法术革命之后，科技与法术共同构成日常。神魔以信仰与恐惧为食，港口城市在战后扩张，而一次宣称成功的登月，至今留下争议。“陆拾肆”收录这个架空世界的设定、人物与故事。</p>
<div class="archive-actions"><a class="archive-primary" href="01-基础设定/时代与纪年.md">从时代与纪年开始 <span aria-hidden="true">↗</span></a><a class="archive-secondary" href="00-导览与索引/总索引.md">浏览总索引 <span aria-hidden="true">→</span></a><a class="archive-secondary" href="档案检索.md">筛选档案 <span aria-hidden="true">→</span></a></div>
<p class="archive-caption">世界观正式总名尚未确定，现暂称“陆拾肆企划”。</p>
</div>

<div class="archive-stats" aria-label="收录概况">
<div><strong>49</strong><span>设定与素材条目</span></div>
<div><strong>19</strong><span>人物角色</span></div>
<div><strong>10</strong><span>主题分类</span></div>
<div><strong>04</strong><span>数据索引</span></div>
</div>

## 初次到访

先了解时代背景与法术的边界，再走进港口城市，认识在那里苏醒的剑灵。

<div class="archive-path">
<a href="01-基础设定/时代与纪年.md"><span class="archive-number">01</span><strong>时代与纪年</strong><span>从三次世界大战，读到法术进入大众生活。</span></a>
<a href="01-基础设定/法术体系.md"><span class="archive-number">02</span><strong>法术体系</strong><span>精神如何影响物质，又为何无法脱离施法者。</span></a>
<a href="02-地理地区/柏格宁.md"><span class="archive-number">03</span><strong>柏格宁</strong><span>跨江大桥上的繁华，与地图之外的荒楼区。</span></a>
<a href="04-人物角色/观.md"><span class="archive-number">04</span><strong>观</strong><span>失忆的剑灵，以“报童”之名接取委托。</span></a>
</div>

## 世界的基本规则

<div class="archive-grid archive-foundations">
<a class="archive-card" href="01-基础设定/世界与界域.md"><span class="archive-kicker">01 / REALMS</span><h3>世界与界域</h3><p>主界与下界是物理世界。神界是神魔本体栖息的精神体世界。</p><span class="archive-more">阅读条目 ↗</span></a>
<a class="archive-card" href="01-基础设定/法术体系.md"><span class="archive-kicker">02 / SPELLCRAFT</span><h3>法术体系</h3><p>法术通过精神力量影响物质世界，其施展始终伴随着精神消耗。</p><span class="archive-more">阅读条目 ↗</span></a>
<a class="archive-card" href="01-基础设定/神魔体系.md"><span class="archive-kicker">03 / DIVINITIES</span><h3>神魔体系</h3><p>神与魔是同一类精神体生物。与它们相关的魔法，是区别于法术的力量。</p><span class="archive-more">阅读条目 ↗</span></a>
<a class="archive-card" href="01-基础设定/险域与禁域.md"><span class="archive-kicker">04 / ANOMALIES</span><h3>险域与禁域</h3><p>险域依危险程度划分。禁域的核心则是超出经典科学解释的异常力量。</p><span class="archive-more">阅读条目 ↗</span></a>
</div>

## 沿故事进入世界

<div class="archive-grid archive-stories">
<section class="archive-card"><span class="archive-kicker">STORYLINE 01 / 柏格宁线</span><h3>大桥之上，旧城之间</h3><p>战后的港口迅速成长。失忆的观在老城区苏醒，接取委托的生活逐渐与行脚商小队相交。</p><div class="archive-story-links"><a href="02-地理地区/柏格宁.md">柏格宁</a><a href="03-组织势力/赫拉小队.md">赫拉小队</a><a href="09-作品与写作素材/素材池/隐约的记忆.md">隐约的记忆</a></div></section>
<section class="archive-card"><span class="archive-kicker">STORYLINE 02 / 源灵线</span><h3>封闭学苑里的生活</h3><p>源灵学苑收纳来自罗瓦伊的孤儿，园区的教育与生活由公司管理。1898 年的变故，让许多人初次进入社会。</p><div class="archive-story-links"><a href="03-组织势力/源灵学苑.md">源灵学苑</a><a href="04-人物角色/菈比.md">菈比</a><a href="05-历史事件/源灵学院变故.md">源灵学院变故</a></div></section>
<section class="archive-card"><span class="archive-kicker">STORYLINE 03 / 禁域调查线</span><h3>没有深入记录的草原</h3><p>编号 ZZ0381 的档案多年没有探查记录。一次核查，使这片草原被重新提档为禁域。</p><div class="archive-story-links"><a href="02-地理地区/ZZ0381草原禁域.md">ZZ0381草原禁域</a><a href="03-组织势力/异常协会.md">异常协会</a><a href="09-作品与写作素材/素材池/调查记录.md">调查记录</a></div></section>
<section class="archive-card"><span class="archive-kicker">STORYLINE 04 / 毒魔线</span><h3>代代传承的名字</h3><p>毒魔教团始终有一位名为以西结的祭司容器。这个代号连接着神祇降临的仪式，也连接着个体的命运。</p><div class="archive-story-links"><a href="03-组织势力/毒魔教团.md">毒魔教团</a><a href="04-人物角色/以西结.md">以西结</a><a href="04-人物角色/何守.md">何守</a></div></section>
</div>

## 人物档案

<div class="archive-characters">
<a class="archive-character" href="04-人物角色/观.md"><span class="archive-character-symbol" aria-hidden="true">观</span><div><h3>观</h3><span>秦若孚 · 报童</span><p>对应观卦的剑灵，能够感知他人的情绪与意图。</p></div><span aria-hidden="true">↗</span></a>
<a class="archive-character" href="04-人物角色/缇尔莉斯.md"><span class="archive-character-symbol" aria-hidden="true">隼</span><div><h3>缇尔莉斯</h3><span>翠隼 · 盖维小队</span><p>偃师工造开发的 HAIA 人形机，承担狙击、侦察与支援。</p></div><span aria-hidden="true">↗</span></a>
<a class="archive-character" href="04-人物角色/菈比.md"><span class="archive-character-symbol" aria-hidden="true">眠</span><div><h3>菈比</h3><span>未眠少女 · 源灵学苑</span><p>能够催眠他人的学生，自身却无法安全入睡。</p></div><span aria-hidden="true">↗</span></a>
</div>

[查看全部人物角色](04-人物角色/index.md)

## 分类阅览

<div class="archive-categories">
<a href="00-导览与索引/index.md"><span>00</span><strong>导览与索引</strong><small>阅读路线与全站目录</small><b aria-hidden="true">↗</b></a>
<a href="01-基础设定/index.md"><span>01</span><strong>基础设定</strong><small>6 条目</small><b aria-hidden="true">↗</b></a>
<a href="02-地理地区/index.md"><span>02</span><strong>地理地区</strong><small>4 条目</small><b aria-hidden="true">↗</b></a>
<a href="03-组织势力/index.md"><span>03</span><strong>组织势力</strong><small>7 条目</small><b aria-hidden="true">↗</b></a>
<a href="04-人物角色/index.md"><span>04</span><strong>人物角色</strong><small>19 条目</small><b aria-hidden="true">↗</b></a>
<a href="05-历史事件/index.md"><span>05</span><strong>历史事件</strong><small>4 条目</small><b aria-hidden="true">↗</b></a>
<a href="06-能力与超常/index.md"><span>06</span><strong>能力与超常</strong><small>2 条目</small><b aria-hidden="true">↗</b></a>
<a href="07-物品与装备/index.md"><span>07</span><strong>物品与装备</strong><small>1 条目</small><b aria-hidden="true">↗</b></a>
<a href="08-物种与种族/index.md"><span>08</span><strong>物种与种族</strong><small>1 条目</small><b aria-hidden="true">↗</b></a>
<a href="09-作品与写作素材/index.md"><span>09</span><strong>作品与写作素材</strong><small>5 条目</small><b aria-hidden="true">↗</b></a>
</div>

## 索引与编务

数据索引按条目属性汇总，提供人物、事件、完成度与正典性的不同阅读入口。

[打开档案检索，组合筛选条目](档案检索.md)

<div class="archive-index-links">
<a href="00-导览与索引/索引-人物角色.base"><strong>人物角色总览</strong><span>按完成度与正典性分组 ↗</span></a>
<a href="00-导览与索引/索引-历史事件.base"><strong>历史事件索引</strong><span>查看事件的完成度与正典性 ↗</span></a>
<a href="00-导览与索引/索引-条目状态.base"><strong>条目状态总览</strong><span>按类型与正典性汇总 ↗</span></a>
<a href="00-导览与索引/索引-待处理.base"><strong>待处理条目</strong><span>查看草稿与骨架条目 ↗</span></a>
</div>

<div class="archive-editor-links"><span>编务文档</span><a href="meta/术语规范与别名对照.md">术语规范与别名对照</a><a href="meta/待决问题与冲突清单.md">待决问题与冲突清单</a><a href="meta/文档维护规则.md">文档维护规则</a><a href="meta/维护说明.md">维护说明</a></div>
